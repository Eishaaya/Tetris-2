﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Tetris
{
    public class Game1 : Game
    {
        enum texas
        {
            menu,
            levels,
            level,
            unlimited
        }
        List<List<Vector2>> locations;
        List<bool> symmetry;
        List<Color> colors;
        List<int> chances;
        Sprite image;
        Sprite Gimage;
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        Grid grid;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferWidth = 600;
            _graphics.PreferredBackBufferHeight = 800;
            _graphics.ApplyChanges();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            locations = new List<List<Vector2>>
            {
                new List<Vector2> { new Vector2 (0, 0) }, // D o t

                new List<Vector2> { new Vector2 (0, 0), new Vector2 (0, 1) }, // Short Beam

                new List<Vector2> { new Vector2 (0, 1), new Vector2 (0, 0), new Vector2 (0, 2) }, // Beam
                new List<Vector2> { new Vector2 (0, 0), new Vector2 (0, 1), new Vector2 (1, 0) }, // Corner

                new List<Vector2> { new Vector2 (0, 1), new Vector2 (0, 0), new Vector2 (0, 2), new Vector2(0, 3) }, // Long Beam
                new List<Vector2> { new Vector2 (0, 1), new Vector2 (0, 0), new Vector2 (1, 1), new Vector2(1, 0) }, // Square

                new List<Vector2> { new Vector2 (0, 1), new Vector2 (0, 0), new Vector2 (0, 2), new Vector2(1, 2) }, // L L
                new List<Vector2> { new Vector2 (1, 1), new Vector2 (1, 0), new Vector2 (1, 2), new Vector2(0, 2) }, // L R
                new List<Vector2> { new Vector2 (0, 1), new Vector2 (0, 0), new Vector2 (0, 2), new Vector2(1, 1) }, // half plus
                new List<Vector2> { new Vector2 (1, 0), new Vector2 (1, 1), new Vector2 (2, 0), new Vector2(0, 1) }, // Z R
                new List<Vector2> { new Vector2 (1, 0), new Vector2 (0, 0), new Vector2 (1, 1), new Vector2(2, 1) }, // Z l

                new List<Vector2> { new Vector2 (1, 1), new Vector2 (1, 0), new Vector2 (0, 1), new Vector2(2, 1), new Vector2(1, 2) }, // +
                new List<Vector2> { new Vector2 (1, 1), new Vector2 (0, 0), new Vector2 (0, 1), new Vector2(2, 1), new Vector2(2, 0) }, // U
                new List<Vector2> { new Vector2 (1, 1), new Vector2 (0, 0), new Vector2 (0, 1), new Vector2(1, 2), new Vector2(2, 2) }, // Diaganol W
                new List<Vector2> { new Vector2 (1, 1), new Vector2 (0, 0), new Vector2 (1, 0), new Vector2(2, 0), new Vector2(1, 2) }, // Dirty British Goods (throw it in the damned harbor)

                new List<Vector2> { new Vector2 (2, 1), new Vector2 (0, 1), new Vector2 (1, 1), new Vector2(1, 0), new Vector2(3, 1), new Vector2(4, 1) }, // Lump Line L
                new List<Vector2> { new Vector2 (2, 1), new Vector2 (0, 1), new Vector2 (1, 1), new Vector2(3, 0), new Vector2(3, 1), new Vector2(4, 1) }, //Lump Line R

                new List<Vector2> { new Vector2 (2, 0), new Vector2 (1, 1), new Vector2 (2, 1), new Vector2(3, 1), new Vector2(0, 2), new Vector2(1, 2), new Vector2 (3, 2), new Vector2 (4, 2), new Vector2 (1, 3), new Vector2(2, 3), new Vector2(3, 3), new Vector2(2, 4) } //Death Donut
      
        };

            chances = new List<int>
            {
                40,

                50,

                60,
                85,

                70,
                100,

                100,
                100,
                100,
                100,
                100,

                80,
                80,
                50,
                60,

                30,
                30,

                10,
            };

            colors = new List<Color>
            {
                Color.Gray,

                Color.Navy,

                Color.DarkBlue,
                Color.LimeGreen,

                Color.Blue,
                Color.MediumSlateBlue,

                Color.Purple,
                Color.MediumPurple,
                Color.Crimson,
                Color.DarkGreen,
                Color.LawnGreen,

                Color.Red,
                Color.CornflowerBlue,
                Color.ForestGreen,
                Color.DarkRed,

                Color.HotPink,
                Color.DeepPink,

                Color.DarkGray,
            };

            symmetry = new List<bool>
            {
                true,

                false,

                false,
                false,

                false,
                true,

                false,
                false,
                false,
                false,
                false,

                true,
                false,
                false,
                false,

                false,
                false,

                true
            };

            image = new Sprite(Content.Load<Texture2D>("tile"), new Vector2(30, 30), Color.White, 0, SpriteEffects.None, new Vector2(30, 30), 1, 1);
            Gimage = new Sprite(Content.Load<Texture2D>("grid"), new Vector2(30, 30), Color.White, 0, SpriteEffects.None, new Vector2(30, 30), 1, 1);
            grid = new Grid(new Vector2(10, 20), Gimage, locations, symmetry, colors, chances, image, (float).6667);
        }

        protected override void Update(GameTime gameTime)
        {
            grid.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            _spriteBatch.Begin();
            grid.Draw(_spriteBatch);
            _spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
