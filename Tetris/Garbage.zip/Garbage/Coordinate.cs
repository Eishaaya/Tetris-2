﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Tetris
{
    class Coordinate
    {
        public Sprite image;
        public Vector2 place;
        public bool isfull;
        public Coordinate(Sprite I, Vector2 P)
        {
            image = I;
            place = P;
            isfull = false;
        }
        public void fill(RatPooeys pooey)
        {
            image.Image = pooey.image.Image;
            image.Color = pooey.image.Color;
            isfull = true;
        }
        public void replace(Coordinate coord)
        {
            Coordinate coor = new Coordinate(new Sprite(coord.image.Image, coord.image.Location, coord.image.Color, coord.image.Rotation, coord.image.Effects, coord.image.Origin, coord.image.Scale, coord.image.Depth), coord.place);
            image = coor.image;
            place = coor.place;
            isfull = coor.isfull;
            //image.Image = coor.image.Image;
            //image.Color = coor.image.Color;
            //image.Scale = coor.image.Scale;
            //image.Location = coor.image.Location;
            //place = coor.place;
            //isfull = coor.isfull;
        }
        public void empty(Sprite empty)
        {
            image = new Sprite(empty.Image, empty.Location, empty.Color, empty.Rotation, empty.Effects, empty.Origin, empty.Scale, empty.Depth);
            isfull = false;
        }
    }
}
